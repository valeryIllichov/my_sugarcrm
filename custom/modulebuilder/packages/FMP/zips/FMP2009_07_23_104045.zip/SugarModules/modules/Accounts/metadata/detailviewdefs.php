<?php
$viewdefs ['Accounts'] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'includes' => 
      array (
        0 => 
        array (
          'file' => 'modules/Accounts/Account.js',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'custno_c',
            'label' => 'LBL_CUSTNO',
          ),
          1 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'billing_address_street',
            'label' => 'LBL_BILLING_ADDRESS',
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'billing',
            ),
          ),
          1 => 
          array (
            'name' => 'shipping_address_street',
            'label' => 'LBL_SHIPPING_ADDRESS',
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'shipping',
            ),
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'phone_office',
            'label' => 'LBL_PHONE_OFFICE',
          ),
          1 => 
          array (
            'name' => 'phone_fax',
            'label' => 'LBL_FAX',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'phone_alternate',
            'label' => 'LBL_OTHER_PHONE',
          ),
          1 => NULL,
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'slsm_c',
            'label' => 'LBL_SLSM',
          ),
          1 => 
          array (
            'name' => 'region_c',
            'label' => 'LBL_REGION',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'location_c',
            'label' => 'LBL_LOCATION',
          ),
          1 => 
          array (
            'name' => 'stocklocation_c',
            'label' => 'LBL_STOCKLOCATION',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'dealertype_c',
            'label' => 'LBL_DEALERTYPE',
          ),
          1 => NULL,
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
      ),
      'lbl_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'mtd_sales_c',
            'label' => 'LBL_MTD_SALES',
          ),
          1 => 
          array (
            'name' => 'mtd_gp_c',
            'label' => 'LBL_MTD_GP',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'ytd_sales_c',
            'label' => 'LBL_YTD_SALES',
          ),
          1 => 
          array (
            'name' => 'ytd_gp_c',
            'label' => 'LBL_YTD_GP',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'ly_sales_c',
            'label' => 'LBL_LY_SALES',
          ),
          1 => 
          array (
            'name' => 'ly_gp_c',
            'label' => 'LBL_LY_GP',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'mtd_budget_sales_c',
            'label' => 'LBL_MTD_BUDGET_SALES',
          ),
          1 => 
          array (
            'name' => 'ytd_budget_sales_c',
            'label' => 'LBL_YTD_BUDGET_SALES',
          ),
        ),
      ),
      'lbl_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'aarbal_c',
            'label' => 'LBL_AARBAL',
          ),
          1 => 
          array (
            'name' => 'arcurrent_c',
            'label' => 'LBL_ARCURRENT',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'arfuture_c',
            'label' => 'LBL_ARFUTURE',
          ),
          1 => 
          array (
            'name' => 'ar30_60_c',
            'label' => 'LBL_AR30_60',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'ar60_90_c',
            'label' => 'LBL_AR60_90',
          ),
          1 => 
          array (
            'name' => 'over_90_c',
            'label' => 'LBL_OVER_90',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'creditlimit_c',
            'label' => 'LBL_CREDITLIMIT',
          ),
          1 => NULL,
        ),
      ),
      'lbl_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'email1',
            'label' => 'LBL_EMAIL',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'technicians_c',
            'label' => 'LBL_TECHNICIANS',
          ),
          1 => 
          array (
            'name' => 'bays_c',
            'label' => 'LBL_BAYS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'description',
            'label' => 'LBL_DESCRIPTION',
          ),
        ),
      ),
    ),
  ),
);
?>
