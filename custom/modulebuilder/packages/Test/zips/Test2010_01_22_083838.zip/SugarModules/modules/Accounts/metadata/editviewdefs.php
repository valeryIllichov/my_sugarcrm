<?php
$viewdefs ['Accounts'] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'SAVE',
          1 => 'CANCEL',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'includes' => 
      array (
        0 => 
        array (
          'file' => 'modules/Accounts/Account.js',
        ),
      ),
    ),
    'panels' => 
    array (
      'lbl_account_information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'custno_c',
            'label' => 'LBL_CUSTNO',
          ),
          1 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
            'displayParams' => 
            array (
              'required' => true,
            ),
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO',
          ),
        ),
      ),
      'lbl_panel3' => 
      array (
        0 => 
        array (
          0 => NULL,
          1 => NULL,
        ),
      ),
      'lbl_panel2' => 
      array (
        0 => 
        array (
          0 => NULL,
          1 => NULL,
        ),
      ),
      'lbl_panel4' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'technicians_c',
            'label' => 'LBL_TECHNICIANS',
          ),
          1 => 
          array (
            'name' => 'bays_c',
            'label' => 'LBL_BAYS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'employees',
            'label' => 'LBL_EMPLOYEES',
          ),
          1 => NULL,
        ),
        2 => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'addl_aftermarket_info_c',
            'label' => 'LBL_ADDL_AFTERMARKET_INFO',
          ),
        ),
      ),
      'lbl_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'fmpconnect_c',
            'label' => 'LBL_FMPCONNECT',
          ),
          1 => 
          array (
            'name' => 'nexpart_c',
            'label' => 'LBL_NEXPART',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'ford_vehicle_count_c',
            'label' => 'LBL_FORD_VEHICLE_COUNT',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'chrysler_vehicle_count_c',
            'label' => 'LBL_CHRYSLER_VEHICLE_COUNT',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'gm_vehicle_count_c',
            'label' => 'LBL_GM_VEHICLE_COUNT',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'other_vehicle_count_c',
            'label' => 'LBL_OTHER_VEHICLE_COUNT',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'dealer_prev_maint_c',
            'label' => 'LBL_DEALER_PREV_MAINT',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'addl_dealer_information_c',
            'label' => 'LBL_ADDL_DEALER_INFORMATION',
          ),
        ),
      ),
      'lbl_panel5' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'fleetmaintenanceoptions_c',
            'label' => 'LBL_FLEET_MAINT_OPT',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fleet_num_vehicles_c',
            'label' => 'LBL_FLEET_NUM_VEHICLES',
          ),
          1 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'fleet_model_name_c',
            'label' => 'LBL_FLEET_MODEL_NAME',
          ),
          1 => 
          array (
            'name' => 'fleet_model_number_c',
            'label' => 'LBL_FLEET_MODEL_NUMBER',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'fleet_model_name2_c',
            'label' => 'LBL_FLEET_MODEL_NAME2',
          ),
          1 => 
          array (
            'name' => 'fleet_model_number2_c',
            'label' => 'LBL_FLEET_MODEL_NUMBER2',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'addl_fleet_info_c',
            'label' => 'LBL_ADDL_FLEET_INFO',
          ),
        ),
      ),
      'lbl_email_addresses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'jobber_num_stores_c',
            'label' => 'LBL_JOBBER_NUM_STORES',
          ),
          1 => 
          array (
            'name' => 'jobber_num_trucks_c',
            'label' => 'LBL_JOBBER_NUM_TRUCKS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'jobber_retailorwholesale_c',
            'label' => 'LBL_JOBBER_RETAILORWHOLESALE',
          ),
          1 => 
          array (
            'name' => 'jobber_affilliation_c',
            'label' => 'LBL_JOBBER_AFFILLIATION',
          ),
        ),
        2 => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'addl_jobber_info_c',
            'label' => 'LBL_ADDL_JOBBER_INFO',
          ),
        ),
      ),
    ),
  ),
);
?>
