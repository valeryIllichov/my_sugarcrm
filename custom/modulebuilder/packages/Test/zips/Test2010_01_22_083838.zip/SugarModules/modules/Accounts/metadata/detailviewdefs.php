<?php
$viewdefs ['Accounts'] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'includes' => 
      array (
        0 => 
        array (
          'file' => 'modules/Accounts/Account.js',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'custno_c',
            'label' => 'LBL_CUSTNO',
          ),
          1 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'name',
            'label' => 'LBL_NAME',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'billing_address_street',
            'label' => 'LBL_BILLING_ADDRESS',
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'billing',
            ),
          ),
          1 => 
          array (
            'name' => 'shipping_address_street',
            'label' => 'LBL_SHIPPING_ADDRESS',
            'type' => 'address',
            'displayParams' => 
            array (
              'key' => 'shipping',
            ),
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'phone_office',
            'label' => 'LBL_PHONE_OFFICE',
          ),
          1 => 
          array (
            'name' => 'phone_alternate',
            'label' => 'LBL_OTHER_PHONE',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'phone_fax',
            'label' => 'LBL_FAX',
          ),
          1 => 
          array (
            'name' => 'dealertype_c',
            'label' => 'LBL_DEALERTYPE',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'region_c',
            'label' => 'LBL_REGION',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'location_c',
            'label' => 'LBL_LOCATION',
          ),
          1 => 
          array (
            'name' => 'stocklocation_c',
            'label' => 'LBL_STOCKLOCATION',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'slsm_c',
            'label' => 'LBL_SLSM',
          ),
          1 => 
          array (
            'name' => 'assigned_user_name',
            'label' => 'LBL_ASSIGNED_TO',
          ),
        ),
      ),
      'lbl_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'mtd_projected_c',
            'label' => 'LBL_MTD_PROJECTED',
          ),
          1 => 
          array (
            'name' => 'ytd_projected_c',
            'label' => 'LBL_YTD_PROJECTED',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'mtd_sales_c',
            'label' => 'LBL_MTD_SALES',
          ),
          1 => 
          array (
            'name' => 'ytd_sales_c',
            'label' => 'LBL_YTD_SALES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'mtd_gppct_c',
            'label' => 'LBL_MTD_GPPCT',
          ),
          1 => 
          array (
            'name' => 'ytd_gppct_c',
            'label' => 'LBL_YTD_GPPCT',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'mtd_gp_c',
            'label' => 'LBL_MTD_GP',
          ),
          1 => 
          array (
            'name' => 'ytd_gp_c',
            'label' => 'LBL_YTD_GP',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'mtd_budget_sales_c',
            'label' => 'LBL_MTD_BUDGET_SALES',
          ),
          1 => 
          array (
            'name' => 'ytd_budget_sales_c',
            'label' => 'LBL_YTD_BUDGET_SALES',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'mtd_budget_gp_c',
            'label' => 'LBL_MTD_BUDGET_GP',
          ),
          1 => 
          array (
            'name' => 'ytd_budget_gp_c',
            'label' => 'LBL_YTD_BUDGET_GP',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'mtd_budget_gppct_c',
            'label' => 'LBL_MTD_BUDGET_GPPCT',
          ),
          1 => 
          array (
            'name' => 'ytd_budget_gppct_c',
            'label' => 'LBL_YTD_BUDGET_GPPCT',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'mly_sales_c',
            'label' => 'LBL_MLY_SALES',
          ),
          1 => 
          array (
            'name' => 'ly_sales_c',
            'label' => 'LBL_LY_SALES',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'ly_gppct_c',
            'label' => 'LBL_LY_GPPCT',
          ),
          1 => 
          array (
            'name' => 'ly_gp_c',
            'label' => 'LBL_LY_GP',
          ),
        ),
      ),
      'lbl_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'aarbal_c',
            'label' => 'LBL_AARBAL',
          ),
          1 => 
          array (
            'name' => 'arcurrent_c',
            'label' => 'LBL_ARCURRENT',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'arfuture_c',
            'label' => 'LBL_ARFUTURE',
          ),
          1 => 
          array (
            'name' => 'ar30_60_c',
            'label' => 'LBL_AR30_60',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'ar60_90_c',
            'label' => 'LBL_AR60_90',
          ),
          1 => 
          array (
            'name' => 'over_90_c',
            'label' => 'LBL_OVER_90',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'creditlimit_c',
            'label' => 'LBL_CREDITLIMIT',
          ),
          1 => NULL,
        ),
      ),
      'lbl_panel4' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'technicians_c',
            'label' => 'LBL_TECHNICIANS',
          ),
          1 => 
          array (
            'name' => 'bays_c',
            'label' => 'LBL_BAYS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'employees',
            'label' => 'LBL_EMPLOYEES',
          ),
          1 => NULL,
        ),
        2 => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'addl_aftermarket_info_c',
            'label' => 'LBL_ADDL_AFTERMARKET_INFO',
          ),
        ),
      ),
      'lbl_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'fmpconnect_c',
            'label' => 'LBL_FMPCONNECT',
          ),
          1 => 
          array (
            'name' => 'nexpart_c',
            'label' => 'LBL_NEXPART',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'ford_vehicle_count_c',
            'label' => 'LBL_FORD_VEHICLE_COUNT',
          ),
          1 => 
          array (
            'name' => 'gm_vehicle_count_c',
            'label' => 'LBL_GM_VEHICLE_COUNT',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'chrysler_vehicle_count_c',
            'label' => 'LBL_CHRYSLER_VEHICLE_COUNT',
          ),
          1 => 
          array (
            'name' => 'other_vehicle_count_c',
            'label' => 'LBL_OTHER_VEHICLE_COUNT',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'dealer_prev_maint_c',
            'label' => 'LBL_DEALER_PREV_MAINT',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'addl_dealer_information_c',
            'label' => 'LBL_ADDL_DEALER_INFORMATION',
          ),
        ),
      ),
      'lbl_panel5' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'fleetmaintenanceoptions_c',
            'label' => 'LBL_FLEET_MAINT_OPT',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'fleet_num_vehicles_c',
            'label' => 'LBL_FLEET_NUM_VEHICLES',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'fleet_model_name_c',
            'label' => 'LBL_FLEET_MODEL_NAME',
          ),
          1 => 
          array (
            'name' => 'fleet_model_number_c',
            'label' => 'LBL_FLEET_MODEL_NUMBER',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'fleet_model_name2_c',
            'label' => 'LBL_FLEET_MODEL_NAME2',
          ),
          1 => 
          array (
            'name' => 'fleet_model_number2_c',
            'label' => 'LBL_FLEET_MODEL_NUMBER2',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'addl_fleet_info_c',
            'label' => 'LBL_ADDL_FLEET_INFO',
          ),
        ),
      ),
      'lbl_panel8' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'jobber_num_stores_c',
            'label' => 'LBL_JOBBER_NUM_STORES',
          ),
          1 => 
          array (
            'name' => 'jobber_num_trucks_c',
            'label' => 'LBL_JOBBER_NUM_TRUCKS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'jobber_retailorwholesale_c',
            'label' => 'LBL_JOBBER_RETAILORWHOLESALE',
          ),
          1 => 
          array (
            'name' => 'jobber_affilliation_c',
            'label' => 'LBL_JOBBER_AFFILLIATION',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'addl_jobber_info_c',
            'label' => 'LBL_ADDL_JOBBER_INFO',
          ),
        ),
      ),
    ),
  ),
);
?>
