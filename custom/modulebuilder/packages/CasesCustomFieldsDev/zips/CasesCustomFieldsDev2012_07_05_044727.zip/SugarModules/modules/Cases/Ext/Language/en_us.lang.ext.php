<?php 
 //WARNING: The contents of this file are auto-generated



    $mod_strings['LBL_REQUEST_DATE'] = 'Request Date';
    $mod_strings['LBL_END_DATE'] = 'End Date';
    $mod_strings['LBL_CONNECTION'] = 'Connection Issue';
    $mod_strings['LBL_CONNECTION_TYPE'] = 'Connection Type';
    $mod_strings['LBL_CONNECTION_TIMING'] = 'When To Connect?';





$mod_strings = array_merge($mod_strings,
	array(
		 'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => "Security Groups",
	)
);


?>