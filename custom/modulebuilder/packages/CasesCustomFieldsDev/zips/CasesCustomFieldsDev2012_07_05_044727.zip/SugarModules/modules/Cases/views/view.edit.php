<?php
require_once('include/EditView/EditView2.php');
 class ViewEdit extends SugarView{
 	var $ev;
 	var $type ='edit';
 	var $useForSubpanel = false;  //boolean variable to determine whether view can be used for subpanel creates
 	var $useModuleQuickCreateTemplate = false; //boolean variable to determine whether or not SubpanelQuickCreate has a separate display function
 	var $showTitle = true;

 	function ViewEdit(){
 		parent::SugarView();
 	}

 	function preDisplay(){
 		$metadataFile = null;
 		$foundViewDefs = false;
 		/* BEGIN - SECURITY GROUPS */ 
 		//get group ids of current user and check to see if a layout exists for that group
 		global $current_user;
		require_once('modules/SecurityGroups/SecurityGroup.php');
		$groupFocus = new SecurityGroup();
		$groupList = $groupFocus->getUserSecurityGroups($current_user->id);
		//reorder by precedence....
		
		foreach($groupList as $groupItem) {
			$GLOBALS['log']->debug("Looking for: ".'custom/modules/' . $this->module . '/metadata/'.$groupItem['id'].'/editviewdefs.php');
			if(file_exists('custom/modules/' . $this->module . '/metadata/'.$groupItem['id'].'/editviewdefs.php')){
				$_SESSION['groupLayout'] = $groupItem['id'];
				$metadataFile = 'custom/modules/' . $this->module . '/metadata/'.$groupItem['id'].'/editviewdefs.php';
			}			
		}
		
 		if(isset($metadataFile)){
 			$foundViewDefs = true;
 		}
 		else
 		/* END - SECURITY GROUPS */ 
 		if(file_exists('custom/modules/' . $this->module . '/metadata/editviewdefs.php')){
 			$metadataFile = 'custom/modules/' . $this->module . '/metadata/editviewdefs.php';
 			$foundViewDefs = true;
 		}else{
	 		if(file_exists('custom/modules/'.$this->module.'/metadata/metafiles.php')){
				require_once('custom/modules/'.$this->module.'/metadata/metafiles.php');
				if(!empty($metafiles[$this->module]['editviewdefs'])){
					$metadataFile = $metafiles[$this->module]['editviewdefs'];
					$foundViewDefs = true;
				}
			}elseif(file_exists('modules/'.$this->module.'/metadata/metafiles.php')){
				require_once('modules/'.$this->module.'/metadata/metafiles.php');
				if(!empty($metafiles[$this->module]['editviewdefs'])){
					$metadataFile = $metafiles[$this->module]['editviewdefs'];
					$foundViewDefs = true;
				}
			}
 		}
 		$GLOBALS['log']->debug("metadatafile=". $metadataFile);
		if(!$foundViewDefs && file_exists('modules/'.$this->module.'/metadata/editviewdefs.php')){
				$metadataFile = 'modules/'.$this->module.'/metadata/editviewdefs.php';
 		}

 		$this->ev = new EditView();
 		$this->ev->ss =& $this->ss;
 		$this->ev->setup($this->module, $this->bean, $metadataFile, 'include/EditView/EditView.tpl');

 	}

 	function display(){
		$this->bean->assigned_user_name = 'fmpconnect';
		$this->bean->assigned_user_id = '4d990d5c-5896-0423-c7e4-4e9db7766163';
		$this->ev->process();
/*		if($this->ev->isDuplicate) {
		   foreach($this->ev->fieldDefs as $name=>$defs) {
		   		if(!empty($defs['auto_increment'])) {
		   		   $this->ev->fieldDefs[$name]['value'] = '';
		   		}
		   }
	}*/
		echo $this->ev->display($this->showTitle);
 	}


 }
?>
